#!/usr/bin/env python
from .cidadaobr import *
from .cpf import *
from .endereco import *
from .infobasica import *
from .rg import *
from .telefone import *